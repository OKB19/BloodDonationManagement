import { LightningElement, wire } from 'lwc';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import Camp from'@salesforce/apex/BloodDonorController.getDonationCamp';
import BLOOD_CAMPS_OBJECT from '@salesforce/schema/Blood_Donation_Camp__c';
import CAMP_NAME from '@salesforce/schema/Blood_Donation_Camp__c.Name';
import DATE_TIME from '@salesforce/schema/Blood_Donation_Camp__c.Date_Time__c';
import LOCATION from '@salesforce/schema/Blood_Donation_Camp__c.Location__c';
export default class DonationCamps extends LightningElement {
    bloodCampObject = BLOOD_CAMPS_OBJECT;
    fields = [CAMP_NAME, DATE_TIME, LOCATION];
    CreateCamp(){
        alert('Camp Created Successfully');
        const evt = new ShowToastEvent({
            title: 'Camp Created Successfully',
            message: 'Your Recorsor has been created',
            mode: 'dismissable',
            varient: 'success',
        });
        this.dispatchEvent(evt);
    }
    camps;
    error;
    columns = [
        {label: 'Camp Name', fieldName: 'Name', type: 'text', editable: true},
        {label: 'Date Time', fieldName: 'Date_Time__c', type: 'date', editable: true},
        {label: 'Location', fieldName: 'Location__c', type: 'text', editable: true},
    ]

    @wire(Camp) wiredcamp({error,data}){
        if(data){
            this.camps = data;
    }else if(error){
        console.log(error); 
        this.camps = undefined;
        this.error = error;
    }
 }
          
}