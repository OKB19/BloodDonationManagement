// bloodDonarPage.js
import { LightningElement, wire } from 'lwc';
import getBloodDonors from '@salesforce/apex/BloodDonorController.getBloodDonors';

export default class BloodDonarPage extends LightningElement {
    donors; // To hold the data fetched from Apex
    error;  // To hold any error encountered

    // Define columns for the lightning-datatable
    columns = [
        { label: 'Donor Name', fieldName: 'Donar_Name__c', type: 'text', sortable: true },
        { label: 'Blood Group', fieldName: 'Blood_Group__c', type: 'text', sortable: true },
        { label: 'Mobile', fieldName: 'Mobile__c', type: 'phone' },
        { label: 'Gender', fieldName: 'Gender__c', type: 'text' },
        { label: 'Email ID', fieldName: 'Email_ID__c', type: 'email' }
    ];

    // Wire service to call the Apex method and get data
    @wire(getBloodDonors)
    wiredDonors({ error, data }) {
        if (data) {
            this.donors = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.donors = undefined;
            console.error('Error fetching donors:', error);
        }
    }
}