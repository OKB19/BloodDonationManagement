import { api, LightningElement, track, wire } from 'lwc';
import BlooddropWalking from '@salesforce/resourceUrl/BloodWalk';
import landingPageLogo from '@salesforce/resourceUrl/BDMSlandingPage2';
import bloodBagCounts from '@salesforce/apex/BloodDonorController.getCount';
import bloodInfoGif from '@salesforce/resourceUrl/HomepageGif';
import bloodInfoGif1 from '@salesforce/resourceUrl/storySet';
export default class Home extends LightningElement {
    @track imageUrl = landingPageLogo;
    @track data;
    @track error;
    @track bloodDrop = BlooddropWalking;
    @track gif = bloodInfoGif;
    @track gif1 = bloodInfoGif1;
    get backgroundStyle() {
        return `background-image: url(${this.imageUrl})`;
    }

    @wire(bloodBagCounts)
    gettingCount({ error, data }) {
        if (data) {
            this.data = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.data = undefined;
            console.log('Error fetching count: ' + error);
        }
    }
}
