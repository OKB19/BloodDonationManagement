import { api, LightningElement, track } from 'lwc';
import LOGO from '@salesforce/resourceUrl/bloodlogo';
// Removed NavigationMixin if you are doing internal routing

export default class NavigationBar extends LightningElement { // No NavigationMixin here
    @track _collapsed = false;

    @api
    get collapsed() {
        return this._collapsed;
    }

    set collapsed(value) {
        this._collapsed = value;
    }

    @track logo = LOGO;
    get navbarClass() {
        return this._collapsed ? 'navbar collapsed' : 'navbar expanded';
    }

    navItems = [
        { label: 'Blood Bank', icon: 'utility:home', pageName: 'Home' },
        { label: 'Inventory', icon: 'utility:database', pageName: 'blood_inventory__c' },
        { label: 'Donation Camps', icon: 'utility:event', pageName: 'donation_camps__c' },
        { label: 'Camp Register', icon: 'utility:edit_form', pageName: 'camp_register__c' },
        { label: 'Hospitals', icon: 'utility:record_create', pageName: 'hospitals_page__c' },
        { label: 'Requests', icon: 'utility:inbox', pageName: 'requests_page__c' },
        { label: 'Donors', icon: 'utility:user', pageName: 'donars_page__c' }
    ];

    toggleMenu() {
        this._collapsed = !this._collapsed;
        const collapseEvent = new CustomEvent('navbartoggle', {
            detail: {
                collapsed: this._collapsed
            }
        });
        this.dispatchEvent(collapseEvent);
    }

    navigateToPage(event) {
        const pageName = event.currentTarget.dataset.pageName;
        
        if (pageName) {
            const navigateEvent = new CustomEvent('navigatepage', {
                detail: {
                    pageName: pageName
                }
            });
            this.dispatchEvent(navigateEvent);
        }
    }
}