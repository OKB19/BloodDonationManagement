import { LightningElement, wire } from 'lwc';
import getHospitalRecord from '@salesforce/apex/BloodDonorController.getHospital';
export default class HospitalPage extends LightningElement {
    hospitals;
    errors;
    columns = [
        { label: 'Hospital Name', fieldName: 'Name', type: 'text', sortable: true },
        { label: 'Email ID	', fieldName: 'Email_ID__c', type: 'text', sortable: true },
        { label: 'Telephone', fieldName: 'Telephone__c', type: 'phone' },
        { label: 'Location', fieldName: 'Location__c', type: 'text' }
       
    ];
    @wire(getHospitalRecord)
    wiredHospitals({ error, data }) {
        if(data){
            this.errors = undefined;
            this.hospitals = data;
        }
        else if(error){
            this.error = error;
            this.hospitals = undefined;
        }
    }
}