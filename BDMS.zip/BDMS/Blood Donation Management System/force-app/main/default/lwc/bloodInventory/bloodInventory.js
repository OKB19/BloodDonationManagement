import { LightningElement, wire, track } from 'lwc';
import { getRecordNotifyChange } from 'lightning/uiRecordApi';
import { getListUi } from 'lightning/uiListApi';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import BLOOD_BANK_INVENTORY_OBJECT from '@salesforce/schema/Blood_Bank_Inventory__c';
import NAME_FIELD from '@salesforce/schema/Blood_Bank_Inventory__c.Name';
import BLOOD_BAG_STATUS_FIELD from '@salesforce/schema/Blood_Bank_Inventory__c.Blood_Bag_Status__c';
import BLOOD_GROUP_FIELD from '@salesforce/schema/Blood_Bank_Inventory__c.Blood_Group__c';
import EXPIRED_STATUS_FIELD from '@salesforce/schema/Blood_Bank_Inventory__c.Expired_Status__c';
import EXPIRY_DATE_FIELD from '@salesforce/schema/Blood_Bank_Inventory__c.Expiry_Date__c';

const COLUMNS = [
    { label: 'Name', fieldName: NAME_FIELD.fieldApiName, editable: true },
    { label: 'Blood Bag Status', fieldName: BLOOD_BAG_STATUS_FIELD.fieldApiName, editable: true },
    { label: 'Blood Group', fieldName: BLOOD_GROUP_FIELD.fieldApiName, editable: true },
    { label: 'Expired Status', fieldName: EXPIRED_STATUS_FIELD.fieldApiName, editable: true },
    { label: 'Expiry Date', fieldName: EXPIRY_DATE_FIELD.fieldApiName, type: 'date', editable: true }
];

export default class BloodBankInventory extends LightningElement {
    @track data;
    @track columns = COLUMNS;
    @track draftValues = [];
    error;

    @wire(getListUi, {
        objectApiName: BLOOD_BANK_INVENTORY_OBJECT,
        listViewApiName: 'All'
    })
    wiredRecords({ error, data }) {
        if (data) {
            this.data = data.records.records.map(record => {
                return {
                    Id: record.id,
                    Name: record.fields.Name ? record.fields.Name.value : '',
                    Blood_Bag_Status__c: record.fields.Blood_Bag_Status__c ? record.fields.Blood_Bag_Status__c.value : '',
                    Blood_Group__c: record.fields.Blood_Group__c ? record.fields.Blood_Group__c.value : '',
                    Expired_Status__c: record.fields.Expired_Status__c ? record.fields.Expired_Status__c.value : '',
                    Expiry_Date__c: record.fields.Expiry_Date__c ? record.fields.Expiry_Date__c.value : ''
                };
            });
        } else if (error) {
            console.error(error);
        }
    }

    handleSave(event) {
        const recordInputs = event.detail.draftValues.slice().map(draft => {
            const fields = Object.assign({}, draft);
            return { fields };
        });

        const promises = recordInputs.map(recordInput => updateRecord(recordInput));
        Promise.all(promises).then(() => {
            this.draftValues = [];
            this.showToast('Success', 'Records updated successfully', 'success');
            return getRecordNotifyChange(recordInputs);
        }).catch(error => {
            console.error(error);
            this.error = error;
            this.showToast('Error', 'Error updating records', 'error');
        });
    }

    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title,
            message,
            variant
        });
        this.dispatchEvent(event);
    }
}
