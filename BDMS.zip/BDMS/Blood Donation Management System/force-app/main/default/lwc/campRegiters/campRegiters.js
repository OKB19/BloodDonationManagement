import { LightningElement } from 'lwc';

export default class CampRegiters extends LightningElement {
    handleStatusChange(event) {
        console.log('Flow status changed: ', event.detail.status);
    }

    handleError(event) {
        console.error('Flow error: ', event.detail);
        alert('An error occurred while loading the flow. Please try again later.');
    }
}