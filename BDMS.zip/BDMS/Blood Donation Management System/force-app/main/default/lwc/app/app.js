import { LightningElement, track } from 'lwc';

export default class App extends LightningElement {
    @track isNavbarCollapsed = false;
    @track currentPage = 'Home'; // Default page

    handleNavbarToggle(event) {
        this.isNavbarCollapsed = event.detail.collapsed;
    }

    handleInternalNavigation(event) {
        this.currentPage = event.detail.pageName;
    }
    get mainContentClass() {
        return this.isNavbarCollapsed ? 'main-content collapsed-margin' : 'main-content expanded-margin';
    }

    get isHomePage() {
        return this.currentPage === 'Home';
    }

    get isInventoryPage() {
        return this.currentPage === 'blood_inventory__c';
    }

    get isDonarPage() {
        return this.currentPage === 'donars_page__c';
    }
    get isDonationCamp(){
        return this.currentPage ==='donation_camps__c';
    }
    get isRaiseRequest(){
        return this.currentPage === 'requests_page__c';
    }
    get isCampRegister(){
        return this.currentPage === 'camp_register__c';
    }
    get isHospitalPage(){
        return this.currentPage === 'hospitals_page__c';
    }
}