declare module "@salesforce/resourceUrl/BloodWalk" {
    var BloodWalk: string;
    export default BloodWalk;
}