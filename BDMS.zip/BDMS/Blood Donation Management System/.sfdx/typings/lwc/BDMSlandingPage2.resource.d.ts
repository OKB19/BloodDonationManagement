declare module "@salesforce/resourceUrl/BDMSlandingPage2" {
    var BDMSlandingPage2: string;
    export default BDMSlandingPage2;
}