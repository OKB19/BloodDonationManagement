declare module "@salesforce/resourceUrl/BDMSlandingPage1" {
    var BDMSlandingPage1: string;
    export default BDMSlandingPage1;
}