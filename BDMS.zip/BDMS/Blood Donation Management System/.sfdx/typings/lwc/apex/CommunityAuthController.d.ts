declare module "@salesforce/apex/CommunityAuthController.doLogin" {
  export default function doLogin(param: {username: any, password: any}): Promise<any>;
}
declare module "@salesforce/apex/CommunityAuthController.registerUser" {
  export default function registerUser(param: {firstName: any, lastName: any, email: any, password: any}): Promise<any>;
}
