declare module "@salesforce/apex/BloodDonorController.getBloodDonors" {
  export default function getBloodDonors(): Promise<any>;
}
declare module "@salesforce/apex/BloodDonorController.getDonationCamp" {
  export default function getDonationCamp(): Promise<any>;
}
declare module "@salesforce/apex/BloodDonorController.getCount" {
  export default function getCount(): Promise<any>;
}
declare module "@salesforce/apex/BloodDonorController.getHospital" {
  export default function getHospital(): Promise<any>;
}
