declare module "@salesforce/resourceUrl/bloodlogo" {
    var bloodlogo: string;
    export default bloodlogo;
}