declare module "@salesforce/resourceUrl/BDMSlandingPage3" {
    var BDMSlandingPage3: string;
    export default BDMSlandingPage3;
}